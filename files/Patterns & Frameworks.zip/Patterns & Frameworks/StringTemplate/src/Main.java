import java.util.function.Function;

import org.stringtemplate.*;
import org.stringtemplate.v4.ST;
import org.stringtemplate.v4.STGroup;
import org.stringtemplate.v4.STGroupDir;

/*******************************************************************************
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *******************************************************************************/

/**
 * @author martijn
 *
 */
public class Main {

	public static void main(String[] args) {
		Main.Artikel artikel = new Main.Artikel("1", "patrick", "fdds");
		Main.Artikel artikel1 = new Main.Artikel("2", "klaas", "falti");
		Main.Artikel artikel2 = new Main.Artikel("3", "patrick", "shon");
		STGroup groep = Main.pakdiegroup.getGroup();
		
		ST st = groep.getInstanceOf("rtikel1");
		st.add("rtikel", artikel);
		
		ST st1 = groep.getInstanceOf("rtikel1");
		st1.add("rtikel", artikel1);
		
		ST st2 = groep.getInstanceOf("rtikel1");
		st2.add("rtikel", artikel2);
		
		System.out.println(st.render());
		System.out.println(st1.render());
		System.out.println(st2.render());
		
	}

	static class Artikel {
		private String titel, inhoud, auteur;

		public Artikel(String titel, String inhoud, String auteur) {
			this.titel = titel;
			this.inhoud = inhoud;
			this.auteur = auteur;
		}

		/**
		 * @return the titel
		 */
		public String getTitel() {
			return titel;
		}

		/**
		 * @param titel the titel to set
		 */
		public void setTitel(String titel) {
			this.titel = titel;
		}

		/**
		 * @return the inhoud
		 */
		public String getInhoud() {
			return inhoud;
		}

		/**
		 * @param inhoud the inhoud to set
		 */
		public void setInhoud(String inhoud) {
			this.inhoud = inhoud;
		}

		/**
		 * @return the auteur
		 */
		public String getAuteur() {
			return auteur;
		}

		/**
		 * @param auteur the auteur to set
		 */
		public void setAuteur(String auteur) {
			this.auteur = auteur;
		}
		

	}
	static class pakdiegroup {
		static STGroup groepie = new STGroupDir("templates", '가', '가');
		
		static public org.stringtemplate.v4.STGroup getGroup(){
			return groepie;
		}
	}
}
