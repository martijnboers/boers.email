package Domein;
import java.util.List;

public class Student {
	private int id;
	private String naam;
	private String adres;
	private List<Cijfer> deCijfers;
	public Student() {
		
	}
	public Student(String nm, String adr) {
		this.setAdres(adr);
		this.setNaam(nm);
	}
	public String getNaam() {
		return naam;
	}
	public void setNaam(String naam) {
		this.naam = naam;
	}
	
	public String getAdres() {
		return adres;
	}
	public void setAdres(String adres) {
		this.adres = adres;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public List<Cijfer> getDeCijfers() {
		return deCijfers;
	}
	
	public void setDeCijfers(List<Cijfer> deCijfers) {
		this.deCijfers = deCijfers;
	}
	
	public String toString() {
		String s = "Student " + this.getNaam() + " woont op " + this.getAdres() + " Met de cijfers:";
		for (Cijfer c : deCijfers) {
			s += "\n" + c;
		}
		return s;
	}
}
