package Domein;

public class Cijfer {
	private int id;
	private String vak;
	private int waarde;
	Cijfer() {
		
	}
	public int getWaarde() {
		return waarde;
	}
	public void setWaarde(int waarde) {
		this.waarde = waarde;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public String getVak() {
		return vak;
	}
	public void setVak(String vak) {
		this.vak = vak;
	}
	
	public String toString() {
		return getWaarde() + " voor het vak " + getVak();
	}
}
