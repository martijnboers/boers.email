package Utility;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateUtil {
	private static HibernateUtil _instance = null;
    private SessionFactory sessionFactory;
    
    private HibernateUtil() {
    	 try {
             // Create the SessionFactory from hibernate.cfg.xml
             sessionFactory = new Configuration().configure().buildSessionFactory();
         } catch (Throwable ex) {
             // Make sure you log the exception
             throw new ExceptionInInitializerError(ex);
         }
    }
    
    private synchronized static void createInstance () {
        if (_instance == null) _instance = new HibernateUtil();
    }
	
	public static HibernateUtil getInstance () {
        if (_instance == null) createInstance ();
        return _instance;
    }

    public SessionFactory getSessionFactory() {
        return sessionFactory;
    }

}