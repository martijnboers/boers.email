package Main;
import org.hibernate.Session;

import Domein.Student;
import Utility.HibernateUtil;

public class Main {
	public static void main(String args[]) {
		//SaveStudentToDatabase(new Student("Piet", "Pietstraat 11")); <!-- doen we niet wegens rechten maar is net zo makkelijk!
		Student theStudent = LoadStudentFromDatabase(1);
		System.out.println(theStudent);
	}

	private static Student LoadStudentFromDatabase(int id) {
		Session session = HibernateUtil.getInstance().getSessionFactory().openSession();
		Student stud = session.load(Student.class, id);
		session.close();
		return stud;
	}
	
	private static void SaveStudentToDatabase(Student student) {
		Session session = HibernateUtil.getInstance().getSessionFactory().openSession();
		session.save(student);
		session.close();
	}
}
