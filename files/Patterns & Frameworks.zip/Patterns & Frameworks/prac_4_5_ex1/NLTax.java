/*******************************************************************************
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *******************************************************************************/
package prac_4_5_ex1;

/**
 * @author martijn
 *
 */
public class NLTax implements Tax {
	// To force new objects for other tax rates tax is final and will have no
	// setter
	private final double tax = 21;
	private static NLTax nl = new NLTax();

	public static NLTax getInstance() {
		return nl;
	}

	@Override
	public double getTax() {
		return tax;
	}

	@Override
	public double taxCalc(double amount) {
		return (1+(tax / 100)) * amount;
	}

}
