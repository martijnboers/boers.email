package com.spark.todoapp;

import com.google.gson.Gson;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;
import org.bson.types.ObjectId;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class TodoService {

    private final MongoDatabase db;
    private final MongoCollection<Document> collection;

    public TodoService(MongoDatabase db) {
        this.db = db;
        this.collection = db.getCollection("todos");
    }

    public List<Todo> findAll() {
        List<Todo> todos = new ArrayList<>();
        FindIterable<Document> dbObjects = collection.find();
        MongoCursor<Document> cursor = dbObjects.iterator();
        while (cursor.hasNext()) {
            Document dbObject = cursor.next();
            todos.add(new Todo(dbObject));
        }
        return todos;
    }

    public void createNewTodo(String body) {
        Todo todo = new Gson().fromJson(body, Todo.class);
        collection.insertOne(new Document("title", todo.getTitle()).append("done", todo.isDone()).append("createdOn", new Date()));
    }

    public Todo find(String id) {
        return new Todo(collection.find(new Document().append("_id", new ObjectId(id))).first());

    }

    public Todo update(String todoId, String body) {
        Todo todo = new Gson().fromJson(body, Todo.class);
        collection.updateOne(new Document("_id", new ObjectId(todoId)), new Document("$set", new Document("done", todo.isDone())));
        return this.find(todoId);
    }

    public void delete(String id){
        collection.deleteOne(new Document().append("_id", new ObjectId(id)));
    }
}
