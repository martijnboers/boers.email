package com.spark.todoapp;

import org.bson.Document;

import java.util.Date;

public class Todo {

    private String id;
    private String title;
    private boolean done;
    private Date createdOn = new Date();

    public Todo(Document document) {
        this.id = (document.get("_id")).toString();
        this.title = document.getString("title");
        this.done = document.getBoolean("done");
        this.createdOn = document.getDate("createdOn");
    }

    public String getTitle() {
        return title;
    }

    public boolean isDone() {
        return done;
    }

    public Date getCreatedOn() {
        return createdOn;
    }
}
