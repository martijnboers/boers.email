package com.spark.todoapp;

import com.mongodb.*;
import com.mongodb.client.MongoDatabase;

import static spark.Spark.*;

public class Bootstrap {
    private static final String IP_ADDRESS = "localhost";
    private static final int PORT = 8080;

    public static void main(String[] args) throws Exception {
        ipAddress(IP_ADDRESS);
        port(PORT);
        staticFileLocation("/public");
        new TodoResource(new TodoService(mongo()));
    }

    private static MongoDatabase mongo() throws Exception {
        String dbname = "todoapp";
        MongoClientOptions mongoClientOptions = MongoClientOptions.builder().connectionsPerHost(20).build();
        MongoClient mongoClient = new MongoClient(IP_ADDRESS, mongoClientOptions);
        mongoClient.setWriteConcern(WriteConcern.SAFE);
        MongoDatabase db = mongoClient.getDatabase(dbname);
        return db;
    }
}
