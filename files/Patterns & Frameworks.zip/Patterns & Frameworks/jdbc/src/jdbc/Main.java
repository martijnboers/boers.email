/*******************************************************************************
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *******************************************************************************/
package jdbc;

import java.net.ConnectException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.jdbc.Statement;

/**
 * @author martijn
 *
 */
public class Main {
	static Connection conn = null;

	public static void main(String[] args) {
		System.out.println("With prep");
		doeDingentjes("");
		System.out.println("Witout prep");
		doeDingentjes("1 or 1=1");
	}

	public static void doeDingentjes(String sqlShizzle) {
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
		} catch (Exception ex) {
		}
		try {
			conn =
					DriverManager.getConnection("jdbc:mysql://a.plebian.nl/test?" +
							"user=informatica&password=informatica");

			if (sqlShizzle == "") {
				PreparedStatement statement = conn.prepareStatement("SELECT NAAM FROM users WHERE ID=?");

				statement.setInt(1, 1);
				ResultSet result = statement.executeQuery();

				while (result.next()) {
					System.out.println(result.getString("naam"));
				}
			}

			else {
				java.sql.Statement stmt = conn.createStatement();
				ResultSet rs = stmt.executeQuery("SELECT * FROM users WHERE id=" + sqlShizzle);
				while (rs.next()) {
					System.out.println(rs.getString("password"));
				}
			}

		} catch (SQLException ex) {
			// handle any errors
			System.out.println("SQLException: " + ex.getMessage());
			System.out.println("SQLState: " + ex.getSQLState());
			System.out.println("VendorError: " + ex.getErrorCode());
		}

	}
}
