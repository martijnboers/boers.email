/*******************************************************************************
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *******************************************************************************/

package nl.hu.v2iac1;


import org.eclipse.jetty.security.ConstraintMapping;
import org.eclipse.jetty.security.ConstraintSecurityHandler;
import org.eclipse.jetty.security.HashLoginService;
import org.eclipse.jetty.security.SecurityHandler;
import org.eclipse.jetty.security.authentication.BasicAuthenticator;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.eclipse.jetty.servlet.ServletHolder;
import org.eclipse.jetty.util.security.Constraint;
import org.eclipse.jetty.util.security.Credential;
import org.glassfish.jersey.servlet.ServletContainer;

public class Main {

	public static void main(String[] args) throws Exception {
		ServletContextHandler context = new ServletContextHandler(ServletContextHandler.NO_SESSIONS);
		context.setContextPath("/");
		Server server = new Server(8080);
		context.setSecurityHandler(basicAuthentication("myrealm", "admin", "admin"));

		ServletHolder servlet = context.addServlet(ServletContainer.class, "/*");

		server.setHandler(context);
		servlet.setInitOrder(0);

		servlet.setInitParameter("com.sun.jersey.api.json.POJOMappingFeature", "true");
		servlet.setInitParameter("jersey.config.server.provider.packages", "nl.hu.v2iac1.rest.resource");

		server.start();
		server.join();

	}

	static final SecurityHandler basicAuthentication(String realm, String username, String password) {
		HashLoginService loginService = new HashLoginService();
	    loginService.setName(realm);
	    loginService.putUser(username, Credential.getCredential(password), new String[]{"user"});
	    
	    Constraint constraint = new Constraint();
	    constraint.setName(Constraint.__BASIC_AUTH);
	    constraint.setRoles(new String[]{"user"});
	    constraint.setAuthenticate(true);
	     
	    ConstraintMapping constraintMapping = new ConstraintMapping();
	    constraintMapping.setConstraint(constraint);
	    constraintMapping.setPathSpec("/secret");
	    
	    ConstraintSecurityHandler constraintSecurityHandler = new ConstraintSecurityHandler();
	    constraintSecurityHandler.setAuthenticator(new BasicAuthenticator());
	    constraintSecurityHandler.setRealmName(realm);
	    constraintSecurityHandler.addConstraintMapping(constraintMapping);
	    constraintSecurityHandler.setLoginService(loginService);
	    
	    return constraintSecurityHandler;    	
	}
}
