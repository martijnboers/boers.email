package nl.hu.v2iac1;

import java.util.Properties;

import java.util.UUID;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;

import javax.*;

import java.util.*;

import javax.activation.*;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class EmailAuth {

	// based on send values
	public boolean emailAuth(String username, String token, String email) {
		if (email == null || email.equals("")) {
			return validateToken(username, token);
		} else if (token == null || token.equals("")) {
			String newToken = generateToken();
			storeToken(username, newToken);
			sendEmail(email, newToken);
			return false;
		}
		return false;
	}

	public String generateToken() {
		String s = UUID.randomUUID().toString();
		return s;
	}

	public boolean validateToken(String username, String token) {
		MongoClient con = connection();
		DB db = con.getDB("auth");
		DBCollection table = db.getCollection("user");

		BasicDBObject query = new BasicDBObject();
		query.put("username", username);

		// run the query and print the re sults out
		DBObject dbObj = table.findOne(query);
		String dbToken = (String) dbObj.get("token");
		if (dbToken.equals(token) == true) {

			return true;
		}
		return false;
	}

	public void sendEmail(String email, String token) {

		// config file needs to be added
		final String username = "";
		final String password = "";

		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.port", "587");

		Session session = Session.getInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(username, password);
			}
		});

		try {

			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress("klaas.foppen@gmail.com"));
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(email));
			message.setSubject("Token auth code");
			message.setText("this is your token\n" + token);

			Transport.send(message);

		} catch (MessagingException e) {
			throw new RuntimeException(e);
		}
	}

	public void storeToken(String username, String token) {
		MongoClient con = connection();
		DB db = con.getDB("auth");
		DBCollection table = db.getCollection("user");
		BasicDBObject document = new BasicDBObject();
		document.put("username", username);
		document.put("token", token);
		table.insert(document);

	}

	public MongoClient connection() {
		MongoClient mongo = new MongoClient("localhost", 27017);
		return mongo;

	}
}
