package nl.hu.v2iac1.rest.resource;

import nl.hu.v2iac1.Configuration;
import nl.hu.v2iac1.EmailAuth;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/topsecret")
@Produces(MediaType.TEXT_PLAIN)
public class TopSecretRestService {
	EmailAuth auth = new EmailAuth();

	@GET
	public Response getSecret(@QueryParam("username") String username, @QueryParam("token") String token,
			@QueryParam("email") String email) {
		Configuration configuration = new Configuration();

		String output = "This is TOPs secret: " + configuration.getValue(Configuration.Key.TOPSECRET);
		String error = "access denied email is send if you added username and email params";

		if (auth.emailAuth(username, token, email)) {
			return Response.status(200).entity(output).build();
		} else {
			return Response.status(200).entity(error).build();

		}

	}

}