package nl.hu.v2iac1.rest.resource;

import nl.hu.v2iac1.Configuration;

import java.io.IOException;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeTokenRequest;
import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.api.client.googleapis.auth.oauth2.GoogleTokenResponse;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.services.oauth2.Oauth2;
import com.google.api.services.oauth2.model.Tokeninfo;

@Path("/verysecret")
@Produces(MediaType.TEXT_PLAIN)
public class VerySecretRestService {

	@GET
	@Produces("text/html")
	public Response getSecret(@QueryParam("code") String code) throws IOException {
		JsonFactory jsonFactory = new JacksonFactory();
		HttpTransport httpTransport = new NetHttpTransport();

		System.out.println(code);
		if (code == null) {
			return Response.status(200)
					.entity("<a href='https://accounts.google.com/o/oauth2/auth?response_type=code&redirect_uri=http://localhost:8080/verysecret&client_id=972345029165-b2h9l6bq26uq3adbdp8ao2lh60g6homq.apps.googleusercontent.com&scope=https://www.googleapis.com/auth/userinfo.email&access_type=offline&approval_prompt=force'>click</a>")
					.build();
		}

		GoogleTokenResponse tokenResponse = new GoogleAuthorizationCodeTokenRequest(httpTransport, jsonFactory,
				"972345029165-b2h9l6bq26uq3adbdp8ao2lh60g6homq.apps.googleusercontent.com", "WfINBF9Qo-k8Ry4e5QRCVzpb",
				code, "http://localhost:8080/verysecret").execute();

		GoogleCredential credential = new GoogleCredential.Builder().setJsonFactory(jsonFactory)
				.setTransport(httpTransport)
				.setClientSecrets("972345029165-b2h9l6bq26uq3adbdp8ao2lh60g6homq.apps.googleusercontent.com",
						"WfINBF9Qo-k8Ry4e5QRCVzpb")
				.build().setFromTokenResponse(tokenResponse);

		Oauth2 oauth2 = new Oauth2.Builder(httpTransport, jsonFactory, credential)
				.setApplicationName("security-opdracht").build();
		Tokeninfo tokenInfo = oauth2.tokeninfo().setAccessToken(credential.getAccessToken()).execute();

		if (oauth2.userinfo().get().execute() != null) {

			Configuration configuration = new Configuration();
			String output = "This is very secret: " + configuration.getValue(Configuration.Key.VERYSECRET) + "<br>Google info: " + oauth2.userinfo().get().execute();
			return Response.status(200).entity(output).build();
		} else {
			return Response.status(200).entity("try again").build();
		}

	}

}